# Gradle AEM Tailer

Documentation is available [here](https://github.com/Cognifide/gradle-aem-plugin/tree/6.1.0-beta#task-aemtail).

## Usage

* Starting - `gradlew` or `gradlew aemTail`
* Stopping - use keys combination *Ctrl + C*

## Configuration

Instance URLs can be configured in file *gradle.properties*.
To skip incident reports for known issues, add log text exclusion rules to file *incidentFilter.txt*.