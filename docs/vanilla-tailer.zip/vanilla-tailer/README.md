# Example project enabling log tailing from remote instances
For more information please refer to plugin docs [Gradle AEM Plugin/aemTail](https://github.com/Cognifide/gradle-aem-plugin/tree/6.1.0-beta#task-aemtail)

## To start
Run `gradlew`.

## To stop
Type `ctrl + c`

## To configure AEM instance
Edit [gradle.properties](gradle.properties)

## To filter logs
Edit [incidentFilter.txt](incidentFilter.txt)
