plugins {
    id("com.cognifide.aem.instance")
}

defaultTasks = listOf("aemTail")

aem {
    tasks {
      tail{
        options {
          incidentFilterPath = aem.props.string("aem.tail.incidentFilterPath") ?: "${aem.project.rootProject.file("incidentFilter.txt")}"
        }
      }
    }
}
