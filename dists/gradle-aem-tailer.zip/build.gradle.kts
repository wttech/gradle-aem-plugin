plugins {
    id("com.cognifide.aem.instance")
}

defaultTasks = listOf("aemTail")