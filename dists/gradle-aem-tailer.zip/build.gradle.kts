plugins {
    id("com.cognifide.aem.instance")
}

defaultTasks("instanceTail")