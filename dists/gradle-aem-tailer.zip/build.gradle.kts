plugins {
    id("com.cognifide.aem.instance")
}

defaultTasks("aemTail")